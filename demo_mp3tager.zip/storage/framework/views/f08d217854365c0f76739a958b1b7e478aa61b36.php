<div class="text-center mb-5 mt-4">
    <a rel="nofollow" class="text-ads"  href="<?php echo e(config('app.text_ad_link')); ?>" target="_blank">
     <?php echo e(config('app.text_ad')); ?>


    </a>
    <a rel="nofollow" class="text-ads"  href="<?php echo e(config('app.text_ad_link_1')); ?>" target="_blank">
      <?php echo e(config('app.text_ad_1')); ?>


    </a>
</div><?php /**PATH C:\xampp\htdocs\naijacrawl soft\demo_mp3tager\resources\views/layouts/text.blade.php ENDPATH**/ ?>