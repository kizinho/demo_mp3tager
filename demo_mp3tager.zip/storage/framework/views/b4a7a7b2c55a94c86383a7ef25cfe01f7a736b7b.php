<footer class="footer">
        <div class="container">
            <div class="row">
               
               
            </div>
            <div class="text-center">
                <p>
                    <a class="logo" href="<?php echo e(url('/')); ?>">
                        <i class="fas fa-compact-disc logo__icon"></i>
                       <?php echo e(config('app.name')); ?>

                    </a>
                    
                    Copyright © 2020-<?php echo e(date('Y')); ?> Theme by Kizsoft, powered by <a class="" href="https://kizzsoft.com" target="_blank">Kizsoft Solution Service</a>
   
                </p>
            </div>
        </div>
    </footer><?php /**PATH C:\xampp\htdocs\naijacrawl soft\customMp3Tager\mp3tagCustom\resources\views/layouts/footer.blade.php ENDPATH**/ ?>