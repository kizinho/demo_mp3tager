<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" />
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
     <link rel="manifest" href="<?php echo e(url('/manifest.json')); ?>">
    <!-- Favicons -->
    <link rel="icon" href="<?php echo e(asset('logo/icon.png')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('logo/icon.png')); ?>">
    <link rel="apple-touch-icon"   href="<?php echo e(asset('logo/icon.png')); ?>">
    <link rel="apple-touch-icon"  href="<?php echo e(asset('logo/icon.png')); ?>">
    <link rel="apple-touch-icon"  href="<?php echo e(asset('logo/icon.png')); ?>">
    <link rel="apple-touch-icon"  href="<?php echo e(asset('logo/icon.png')); ?>">
    <?php echo $__env->yieldContent('title'); ?>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Signika&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/font.css')); ?>">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/aos.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" />
    <link href="<?php echo e(asset('sweetalert/sweetalert.css')); ?>" rel="stylesheet" />
    <style>
        .toast {
            opacity: 0.9!important;
        }

    </style>

</head>
<body>
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <div class="modal" style="display: none">
        <div class="mcenter">
            <img src="<?php echo e(asset('images/reload.gif')); ?>"  >
        </div>
    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-161752442-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-161752442-1');
</script>

    <script type="text/javascript">
function googleTranslateElementInit() {
    new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('script/aos.js')); ?>"></script>

    <script src="<?php echo e(asset('script/script.js')); ?>"></script>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="<?php echo e(asset('sweetalert/sweetalert.min.js')); ?>"></script>

    <script>
$(".deleted").on("submit", function () {

    return confirm("Are you sure?");
});
    </script>

    <script>
        $(".deleted-list").on("submit", function () {

            return confirm("Are you sure?");
        });
    </script>

    <?php if(session()->has('message.level')): ?>
    <script type="text/javascript">
        swal({
            title: "<?php echo e(session('message.level')); ?>",
            html: true,
            text: "<span style='color:<?php echo e(session('message.color')); ?>;font-size:20px;margin:10px'><?php echo session('message.content'); ?>",
            timer: 10000,
            type: "<?php echo e(session('message.level')); ?>",
            confirmButtonColor: "#DA0353"
        }).then((value) => {
            //location.reload();
        }).catch(swal.noop);
    </script>
    <?php endif; ?>
<!--     <script>

/*Register Service Worker if it is supported*/
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/mp3sw.js').then(event => {
        }).catch((err) => {
            console.log(err);
        });
    });
} else {
    console.log('No service worker');
}

    </script>-->
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\naijacrawl soft\customMp3Tager\mp3tagCustom\resources\views/layouts/app.blade.php ENDPATH**/ ?>