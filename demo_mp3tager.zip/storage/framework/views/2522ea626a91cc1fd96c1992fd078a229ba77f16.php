<?php $__env->startSection('title'); ?>
<title>You are offline</title>
<meta name="description" content="Looks like your internet is disconnected. Please make sure you aren't marching any cable, we'll be waiting." />
<meta name="keywords" content="Looks like your internet is disconnected. Please make sure you aren't marching any cable, we'll be waiting." />
<meta name="apple-mobile-web-app-title" content="Mp3Tager" />
<meta property="fb:app_id" content="" />
<meta name="theme-color" content="#08192D"/>
<meta property="og:title" content="Looks like your internet is disconnected. Please make sure you aren't marching any cable, we'll be waiting." />
<meta property="og:description" content="Looks like your internet is disconnected. Please make sure you aren't marching any cable, we'll be waiting." />
<meta property="og:url" content="<?php echo e(url('/')); ?>" />
<meta property="og:type" content="website" />
<meta property="og:site_name" content="Mp3Tager" />
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@mp3tager">
<meta name="twitter:title" content="Looks like your internet is disconnected. Please make sure you aren't marching any cable, we'll be waiting.">
<meta name="twitter:description" content="Looks like your internet is disconnected. Please make sure you aren't marching any cable, we'll be waiting.">
<link rel="canonical" href="<?php echo e(url('/')); ?>" />
<meta property="og:image" content="<?php echo e(asset('logo/logo.png')); ?>" />
<meta property="og:image:alt" content="Looks like your internet is disconnected. Please make sure you aren't marching any cable, we'll be waiting.">
<meta property="og:image:type" content="image/png" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta name="twitter:image" content="<?php echo e(asset('logo/logo.png')); ?>" />
<meta name="twitter:image:alt" content="Looks like your internet is disconnected. Please make sure you aren't marching any cable, we'll be waiting." />
<link rel="stylesheet" href="<?php echo e(asset('css/error.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="Mycontainer">
    <div class="error-content">
        <div>
            <h1>Offline</h1>
            <p>Try turn on your internet connection, we'll be waiting..</p>
            <a onClick="window.location.reload();" href="#"><span> Click to   </span>Refresh<i class="fa fa-plug"></i></a>
        </div>
    </div>
    <div class="error-content-dup">
        <h1>Offline</h1>
        <p>Try turn on your internet connection, we'll be waiting..</p>
        <a onClick="window.location.reload();" href="#"><span> Click to   </span>Refresh<i class="fa fa-plug"></i></a>
    </div>    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\naijacrawl soft\mp3tag\resources\views/pages/offline.blade.php ENDPATH**/ ?>