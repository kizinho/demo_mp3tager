
<?php $__env->startSection('title'); ?>
<title>Upload mp3 -  join two mp3 files online | mp3 tager for editing mp3 and Mp4  files <?php echo e(date('Y')); ?></title>
<meta name="description" content="Upload and use this free online editor tool for editing mp3 and Mp4  files   , join mp3  or voice tag , editing of mp3 tags like changing the cover art , album, title, of any mp3 files " />
<meta name="keywords" content="Upload mp3 -  join two mp3 files online | mp3 tager for editing mp3 and Mp4  files" />
<meta name="apple-mobile-web-app-title" content="Mp3Tager" />
<meta property="fb:app_id" content="" />
<meta name="theme-color" content="#08192D"/>
<meta property="og:title" content="Upload mp3 -  join two mp3 files online | mp3 tager for editing mp3 and Mp4  files" />
<meta property="og:description" content="Upload and use this free online editor tool for editing mp3 and Mp4  files   , join mp3  or voice tag , editing of mp3 tags like changing the cover art , album, title, of any mp3 files " />
<meta property="og:url" content="<?php echo e(url('/')); ?>" />
<meta property="og:type" content="website" />
<meta property="og:site_name" content="Mp3Tager" />
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@mp3tager">
<meta name="twitter:title" content="Upload mp3 -  join two mp3 and Mp4  files online | mp3 tager for editing mp3 files">
<meta name="twitter:description" content="Upload and use this free online editor tool for editing mp3 and Mp4  files   , join mp3  or voice tag , editing of mp3 tags like changing the cover art , album, title, of any mp3 files ">
<link rel="canonical" href="<?php echo e(url('/')); ?>" />
<meta property="og:image" content="<?php echo e(url(config('app.logo'))); ?>" />
<meta property="og:image:alt" content="Upload mp3 -  join two mp3 files online | mp3 tager for editing mp3 and Mp4  files">
<meta property="og:image:type" content="image/png" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta name="twitter:image" content="<?php echo e(url(config('app.logo'))); ?>" />
<meta name="twitter:image:alt" content="Upload mp3 -  join two mp3 files online | mp3 tager for editing mp3 and Mp4  files" />

<link rel="stylesheet" href="<?php echo e(asset('css/tags.css')); ?>">
<style>


    input[type="checkbox"] { 
        position: absolute;
        opacity: 0;
    }

    /* Normal Track */
    input[type="checkbox"].ios-switch + div {
        vertical-align: middle;
        border: 1px solid #cd6133;
        border-radius: 999px;
        background-color: rgba(0, 0, 0, 0.1);
        -webkit-transition-duration: .4s;
        -webkit-transition-property: background-color, box-shadow;
        box-shadow: inset 0 0 0 0px rgba(0,0,0,0.4);
        white-space: nowrap;
        cursor: pointer;
    }

    /* Checked Track (Blue) */
    input[type="checkbox"].ios-switch:checked + div {

        background-position: 0 0;
        background-color: #cd6133;
        border: 1px solid #cd6133;
        box-shadow: inset 0 0 0 10px #cd6133;
    }

    /* Tiny Track */
    input[type="checkbox"].tinyswitch.ios-switch + div {
        width: 34px;    height: 18px;
    }



    /* Normal Knob */
    input[type="checkbox"].ios-switch + div > div {
        float: left;
        width: 18px; height: 18px;
        border-radius: inherit;
        background: #ffffff;
        -webkit-transition-timing-function: cubic-bezier(.54,1.85,.5,1);
        -webkit-transition-duration: 0.4s;
        -webkit-transition-property: transform, background-color, box-shadow;
        -moz-transition-timing-function: cubic-bezier(.54,1.85,.5,1);
        -moz-transition-duration: 0.4s;
        -moz-transition-property: transform, background-color;
        box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.3), 0px 0px 0 1px rgba(0, 0, 0, 0.4);
        pointer-events: none;
        margin-top: 1px;
        margin-left: 1px;
    }


    /* Tiny Knob */
    input[type="checkbox"].tinyswitch.ios-switch + div > div {
        width: 16px; height: 16px;
        margin-top: 1px;
    }

    /* Checked Tiny Knob (Blue Style) */
    input[type="checkbox"].tinyswitch.ios-switch:checked + div > div {
        -webkit-transform: translate3d(16px, 0, 0);
        -moz-transform: translate3d(16px, 0, 0);
        box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.3), 0px 0px 0 1px #cd6133;
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Start of tags pages -->
<div class="Mycontainer">
    <div class="upload-container">
        <?php if(config('app.ads_enable') == true): ?>
        <?php echo $__env->make('layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <form id="savetag" enctype="multipart/form-data" autocomplete="on"> 

            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <input type="hidden"  id='id'  value="<?php echo e($tag->id); ?>">
            <input type="hidden"  name='id[<?php echo e($key); ?>]'  value="<?php echo e($tag->id); ?>">
            <input type="hidden"  name='path[<?php echo e($key); ?>]' value="<?php echo e($tag->path); ?>">
            <div class="tag-field-head alert alert-success">
                <div class="row">
                    <div class="col-sm tag-title">
                        <label class="tag-responsive-p " id="title"><span class='badge badge-primary'> <?php echo e($loop->iteration); ?></span> <?php echo e($tag->file_name); ?></label>
                    </div>
                </div>
            </div>
            <?php if($tag->mime_type == 'mp3'): ?>
            <div class="tag-field">
                <div class="row">
                    <div class="col-sm">
                        <label class="tag-responsive-p">Existing image</label>
                    </div>
                    <div class="col-sm browse-btn-cont preview-field"  onchange="loadFile(this)">
                        <?php if(empty($tag->cover_art)): ?>
                        uploaded Song has no cover art
                        <?php else: ?>
                        <img id="picture" src=" <?php echo e($tag->cover_art); ?>" alt= "<?php echo e($tag->file_name); ?>" />
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!--------------------------------------- start selection -------------------------->
            <div class="tag-field tag-field-join" data-render="<?php echo e($key); ?>"> <!-- variable here -->
                <div class="row">
                    <div class="col-sm" data-render="<?php echo e($key); ?>"> <!-- variable here -->
                        <label class="tag-responsive-p">Join Voice Tag or Join Another Song ? (optional)</label>
                        <input type="file" id="mp3Browser-<?php echo e($key); ?>"  data-type='txt' name="viocetag[<?php echo e($key); ?>]"  class="d-nn" accept=".mp3"> <!-- variable here -->
                        <!-- =============Range section================ -->
                        <div class="contorlRange">
                            <label class="currentPosition">0</label>
                            <input type="range" name="" id="songRange-<?php echo e($key); ?>" class="songRange" min="0" max="<?php echo e($tag->seconds); ?>" value="0">
                            <label><?php echo e($tag->seconds); ?></label>
                        </div>
                        <div class="contorlRangeBtn my-2">
                            <button type="button" class="setRangeBtn">Add Join Point {secs}</button>
                        </div>
                        <!-- =============End Range section================ -->
                    </div>
                    <?php if(empty($tag_settings) || $tag_settings->active == false): ?>
                    <div class="col-sm browse-btn-cont align-self-center">
                        <label for=""  class="browse-btn browse-btn-js">Browse</label> <!-- variable here -->
                        <input type="text" placeholder="mp3 ,  wav"  class="song-txt-title"  id="aud-text-<?php echo e($key); ?>" readonly> <!-- variable here -->
                        <!-- =================Browse section=============== -->
                        <div class="rangeValue my-2" id="rangeValue-<?php echo e($key); ?>" data-render="<?php echo e($key); ?>"><!-- variable here -->
                            <input type="hidden" name="joinSelect[<?php echo e($key); ?>]" class="holder" id="holder-<?php echo e($key); ?>" ><!-- variable here -->
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="col-sm browse-btn-cont align-self-center">
                        <!-- =================Browse section=============== -->
                        <label class="tag-responsive-p"> Tager Setting</label>

                        <div class="mb-1">
                            <label> <input type="checkbox"  value="<?php echo e($tag_settings->active); ?>"  name="tager_setting_active" <?php if($tag_settings->active == true): ?>  checked='checked' <?php endif; ?> class="ios-switch green tinyswitch"  /><div><div></div></div></label>

                        </div>
                        <div class="rangeValue my-2" id="rangeValue-<?php echo e($key); ?>" data-render="<?php echo e($key); ?>"><!-- variable here -->
                            <input type="hidden" name="joinSelect[<?php echo e($key); ?>]" class="holder" id="holder-<?php echo e($key); ?>" ><!-- variable here -->
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php if(config('app.ads_enable') == true): ?>
            <?php echo $__env->make('layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <!--------------------------------------- End selection -------------------------->
            <?php if(empty($tag_settings) || $tag_settings->active == false): ?>
            <div class="tag-field tag-field-img"  data-render="<?php echo e($loop->iteration); ?>"> <!-- variable here -->
                <div class="row">
                    <div class="col-sm">
                        <label class="tag-responsive-p">Select image file (up to 2Mb) </label>
                        <input type="file" id='img-file-<?php echo e($loop->iteration); ?>' name="coverart[<?php echo e($key); ?>]" data-type='img' class="d-nn" accept=".png,.jpg,.jpeg"> <!-- variable here -->
                    </div>
                    <div class="col-sm browse-btn-cont img-txt-style">
                        <label for="img-file-<?php echo e($loop->iteration); ?>" class="browse-btn">Browse</label> <!-- variable here -->
                        <input type="text" placeholder="png , jpg , jpeg"   id="img-text-<?php echo e($loop->iteration); ?>" readonly> <!-- variable here -->
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php else: ?> 
            <!-- =========== watermark ===========-->
            <div class="tag-field tag-responsive">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="watermarkSelect">[ optional ]
                            <select class="markSelect" name="watermark[<?php echo e($key); ?>]" data-render="<?php echo e($loop->iteration); ?>"> <!-- variable here -->
                                <option value="" selected disabled>Add WaterMark </option>
                                <option value="1">logo top left</option>
                                <option value="2">logo top Right</option>
                                <option value="3">logo bottom left</option>
                                <option value="4">logo bottom Right</option>
                                <option value="5">Text top Left</option>
                                <option value="6">Text top Right</option>
                                <option value="7">Text bottom left</option>
                                <option value="8">Text bottom Right</option>
                                <option value="9">Moving Text</option>
                            </select>
                        </div>

                    </div>
                    <?php if(config('app.ads_enable') == true): ?>
                    <?php echo $__env->make('layouts.text', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                    <div class="col-sm-6">
                        <?php if(empty($tag_settings) || $tag_settings->active == false): ?>

                        <div class="waterMarkcont" id="waterMarkcont-<?php echo e($loop->iteration); ?>"> <!-- variable here -->
                            <label class="waterMarkBtn">Browse</label>
                            <input type="text"  readonly placeholder="png , jpeg , jpg" class="waterMarkImgUrl">
                            <input type="file" name="watermark_image[<?php echo e($key); ?>]"  class="waterMarkfile" accept=".png,.jpg,.jpeg" style="display: none;">
                        </div>
                        <?php else: ?>
                        <div class="waterMarkcont  mb-1" id="waterMarkcont-<?php echo e($loop->iteration); ?>">

                            <label>Use image <input type="checkbox"  name="tager_setting_active" class="ios-switch green tinyswitch"  /><div><div></div></div></label>

                        </div>

                        <?php endif; ?>
                        <?php if(empty($tag_settings) || $tag_settings->active == false): ?>
                        <div class="waterMarkTxt" id="waterMarkTxt-<?php echo e($loop->iteration); ?>"> <!-- variable here -->
                            <input type="text" name="watermark_text[<?php echo e($key); ?>]" placeholder="Enter your watermark text">
                            <div class="row control-cont">
                                <div class="col-sm-6 my-2">
                                    <input type="color" name="watermark_color[<?php echo e($key); ?>]" data-selected-color='#000000' class="inptColor" required>
                                </div>
                                <div class="col-sm-6 my-2">
                                    <input type="text" name="watermark_font[<?php echo e($key); ?>]" value="23" placeholder="font size eg 20,40" data-font-size="23" class="logo-fnt-size" name="">
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="waterMarkTxt" id="waterMarkTxt-<?php echo e($loop->iteration); ?>"> <!-- variable here -->

                            <label>Use text <input type="checkbox"  name="tager_setting_active_text" class="ios-switch green tinyswitch"  /><div><div></div></div></label>

                            <input type="hidden" value="<?php echo e($tag_settings->water_text); ?>" name="watermark_text[<?php echo e($key); ?>]" placeholder="Enter your watermark text">

                            <input type="hidden" value="<?php echo e($tag_settings->water_color); ?>" name="watermark_color[<?php echo e($key); ?>]" data-selected-color='<?php echo e($tag_settings->water_color); ?>' class="inptColor" required>

                            <input type="hidden" value="<?php echo e($tag_settings->water_font); ?>"  name="watermark_font[<?php echo e($key); ?>]" value="<?php echo e($tag_settings->water_font); ?>" placeholder="font size eg 20,40" data-font-size="<?php echo e($tag_settings->water_font); ?>" class="logo-fnt-size">
                        </div>
                        <?php endif; ?>


                    </div>
                </div>
            </div>
            <!-- ===========End of watermark ===========-->
            <?php endif; ?>


            <div class="tag-field tag-responsive">
                <div class="row">
                    <div class="col-sm">
                        <label>Title</label>
                    </div>
                    <div class="col-sm">
                        <input type="text" placeholder='Enter Title' name="title[<?php echo e($key); ?>]" value="<?php echo e($tag->title); ?>" required>
                    </div>
                </div>
            </div>
            <div class="tag-field tag-responsive">
                <div class="row">
                    <div class="col-sm">
                        <label>Artist</label>
                    </div>
                    <div class="col-sm">
                        <input type="text" placeholder='Enter Artist Name' name="artist[<?php echo e($key); ?>]" value=" <?php echo e($tag->artist); ?>" required>
                    </div>
                </div>
            </div>
            <div class="tag-field tag-responsive">
                <div class="row">
                    <div class="col-sm">
                        <label>Album</label>
                    </div>
                    <div class="col-sm">
                        <input type="text" placeholder='Album' name="album[<?php echo e($key); ?>]" value=" <?php echo e($tag->album); ?>" required>
                    </div>
                </div>
            </div>
            <?php if($tag->mime_type == 'mp3'): ?>
            <div class="tag-field tag-responsive">
                <div class="row">
                    <div class="col-sm">
                        <label>Track Number</label>
                    </div>
                    <div class="col-sm">
                        <input type="text" placeholder='Track Number' name="track_number[<?php echo e($key); ?>]" value=" <?php echo e($tag->track_number); ?>" required>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php if(empty($tag_settings) || $tag_settings->active == false): ?>
            <div class="tag-field tag-responsive">
                <div class="row">
                    <div class="col-sm">
                        <label>Genre</label>
                    </div>
                    <div class="col-sm">
                        <input type="text" placeholder='Genre' name="genre[<?php echo e($key); ?>]" value=" <?php echo e($tag->genre); ?>" required>
                    </div>
                </div>
            </div>
            <div class="tag-field tag-responsive">
                <div class="row">
                    <div class="col-sm">
                        <label>Comments</label>
                    </div>
                    <div class="col-sm">
                        <input type="text" placeholder='comments' name="comments[<?php echo e($key); ?>]" value=" <?php echo e($tag->comments); ?>" required>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php if($tag->mime_type == 'mp3'): ?>
            <div class="tag-field tag-responsive">
                <div class="row">
                    <div class="col-sm">
                        <label>Year</label>
                    </div>
                    <div class="col-sm">
                        <input type="text" placeholder='year' name="year[<?php echo e($key); ?>]" value=" <?php echo e($tag->year); ?>" required>
                    </div>
                </div>
            </div>
            <?php if(empty($tag_settings) || $tag_settings->active == false): ?>
            <div class="tag-field tag-responsive">
                <div class="row">
                    <div class="col-sm">
                        <label>Publisher</label>
                    </div>
                    <div class="col-sm">
                        <input type="text" placeholder='Publisher' name="publisher[<?php echo e($key); ?>]" value=" <?php echo e($tag->publisher); ?>">
                    </div>
                </div>
            </div>
            <input type="hidden" placeholder='Encoded by' name="encoded_by[<?php echo e($key); ?>]" value=" <?php echo e($tag->encoded_by); ?>" required>

            <!--            <div class="tag-field tag-responsive">
                            <div class="row">
                                <div class="col-sm">
                                    <label>Encoded by</label>
                                </div>
                                <div class="col-sm">
                                    <input type="text" placeholder='Encoded by' name="encoded_by[<?php echo e($key); ?>]" value=" <?php echo e($tag->encoded_by); ?>">
                                </div>
                            </div>
                        </div>-->
            <input type="hidden" placeholder='Composer' name="composer[<?php echo e($key); ?>]" value=" <?php echo e($tag->composer); ?>">

            <!--            <div class="tag-field tag-responsive">
                            <div class="row">
                                <div class="col-sm">
                                    <label>Composer</label>
                                </div>
                                <div class="col-sm">
                                    <input type="text" placeholder='Composer' name="composer[<?php echo e($key); ?>]" value=" <?php echo e($tag->composer); ?>">
                                </div>
                            </div>
                        </div>-->
            <input type="hidden" placeholder='Encoder Settings' name="encoder_settings[<?php echo e($key); ?>]" value=" <?php echo e($tag->encoder_settings); ?>">

            <!--
                        <div class="tag-field tag-responsive">
                            <div class="row">
                                <div class="col-sm">
                                    <label>Encoder Settings</label>
                                </div>
                                <div class="col-sm">
                                    <input type="text" placeholder='Encoder Settings' name="encoder_settings[<?php echo e($key); ?>]" value=" <?php echo e($tag->encoder_settings); ?>">
                                </div>
                            </div>
                        </div>-->


            <?php endif; ?>
            <?php endif; ?>

            <?php if($tag->mime_type =='mp3' || $tag->mime_type =='mp4'): ?>
            <?php else: ?>
            <!-- =================End is private section======================= -->
            <div class="tag-field tag-responsive">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="watermarkSelect">Invalid FIle Extension

                        </div>

                    </div>
                    <div class="col-sm-6">

                        <select class="markSelect form-control" name="extension[<?php echo e($key); ?>]"         <?php if($tag->mime_type !=='mp3' || $tag->mime_type !=='mp4'): ?> required  <?php endif; ?>> <!-- variable here -->
                                <option value="" selected disabled>Check your File Extension </option>
                            <option value="mp3">Mp3</option>
                            <option value="mp4">Mp4</option>
                        </select>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(config('app.ads_enable') == true): ?>
            <?php echo $__env->make('layouts.text', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <div class="tag-field tag-responsive">
                <div class="row">
                    <div class="col-sm sub-btn-form">
                        <input type="submit" value="apply and save">
                    </div>
                </div>
            </div>

        </form>
        <!-- End of container -->
    </div>
</div>
<?php $__env->startSection('script'); ?>
<!--  var name = $("input[name=name]").val();-->

<script>

    $('#savetag').submit(function (event) {
        event.preventDefault();
        var formData = new FormData($(this)[0]);
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            beforeSend: function () {
                $(".modal").show();
            },
            complete: function () {
                $(".modal").hide();


            }
        });
        let id = jQuery('#id').val();
        checkProgress(id);
        jQuery.ajax({
            url: "<?php echo e(url('tags')); ?>",
            type: 'POST',
            data: new FormData(this),
            dataType: 'JSON',
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                if (data.data['status'] === 401) {
                    jQuery.each(data.data['message'], function (key, value) {
                        var message = ('' + value + '');
                        toastr.error(message, {timeOut: 50000});
                    });
                    return false;
                }
                if (data.data['status'] === 409) {
                    jQuery.each(data.data['message'], function (key, value) {
                        var message = ('' + value + '');
                        toastr.error(message, {timeOut: 50000});
                    });
                    return false;
                }
                if (data.data['status'] === 422) {
                    var message = data.data['message'];

                    toastr.error(message, {timeOut: 50000});

                    return false;
                }
                if (data.data['status'] === 404) {
                    var message = data.data['message'];

                    toastr.error(message, {timeOut: 50000});

                    return false;
                }
                if (data.data['status'] === 500) {
                    var message = data.data['message'];

                    toastr.error(message, {timeOut: 50000});

                    return false;
                }
                if (data.data['status'] === 411) {
                    var message = data.data['message'];

                    toastr.error(message, {timeOut: 50000});

                    return false;
                }


            }

        });


        function checkProgress(id) {
            var check = setInterval(function () {
                jQuery.ajax({
                    url: "<?php echo e(url('get-tags')); ?>",
                    data: {id: id},
                    method: 'GET',
                    success: function (data) {
                        if (data.data['status'] === 200) {
                            let url = data.data['data'];
                            /*Finish*/
                            clearInterval(check);
                            window.location.href = "<?php echo e(url('/downloads')); ?>?" + url;

                            return false;
                        }

                    }

                });
            }, 6000);

        }

    });

</script> 
<script>
    $('.waterMarkfile').change(function (e) {
        $(this).prev().val(e.target.files[0].name)
    })
    $('.waterMarkBtn').click(function () {
        $(this).next().next().click();
    })
    $('.markSelect').change(function () {
        var renderIndex = $(this).attr('data-render');
        var selectMarkOption1 = `#waterMarkcont-${renderIndex}`
        var selectMarkOption2 = `#waterMarkTxt-${renderIndex}`
        if ($(this).val() == 1 || $(this).val() == 2 || $(this).val() == 3 || $(this).val() == 4) {
            $(`${selectMarkOption1}`).css('display', 'flex')
            $(`${selectMarkOption2}`).css('display', 'none')
        } else if ($(this).val() == 5 || $(this).val() == 6 || $(this).val() == 7 || $(this).val() == 8 || $(this).val() == 9) {
            $(`${selectMarkOption1}`).css('display', 'none')
            $(`${selectMarkOption2}`).css('display', 'block')
        }
    })

    $('.inptColor').change(function () {
        $(this).attr("data-selected-color", $(this).val())
    })
    $('.logo-fnt-size').keyup(function () {
        $(this).attr("data-font-size", $(this).val())
    })



    //--------------- End of water mark section---------------

    $("input[type = file]").change(function (e) {
        var parentIndex = $(this).parent().parent().parent().attr('data-render');
        var txtclear = "#aud-text-" + parentIndex;
        if ($(this).attr('data-type') == 'txt')
            $(txtclear).val(e.target.files[0].name);
    })
    $("input[type = file]").change(function (e) {
        var parentIndexImg = $(this).parent().parent().parent().attr('data-render');
        var mylbltext = "#img-text-" + parentIndexImg;
        if ($(this).attr('data-type') == 'img')
            $(mylbltext).val(e.target.files[0].name);
    })


    var rangValusAray = [];
    $('.setRangeBtn').click(function () {
        var rangBtnIndex = $(this).parent().parent().attr("data-render");
        var rangId = `songRange-${rangBtnIndex}`;
        var appendId = `rangeValue-${rangBtnIndex}`
        var holderId = `holder-${rangBtnIndex}`
        rangValue = $(`#${rangId}`).val()
        if (rangValusAray[rangBtnIndex] == null) {
            var currntArry = [];
            currntArry.push(rangValue)
            rangValusAray.push(currntArry)
        } else {
            var oldarr = rangValusAray[rangBtnIndex];
            oldarr.push(rangValue)
        }
        var child = `<p class="val-cont"><span class="rangeHolder">${rangValue}</span><span class="btnRangclear fas fa-times-circle" data-range-index="${rangValue}"></span></p>`
        $(`#${appendId}`).append(child)
        $(`#${holderId}`).attr("value", rangValusAray[rangBtnIndex])
    })
    $(document).click(function (e) {
        if (e.target.classList.contains("btnRangclear")) {
            var holderIdIndex = e.target.parentNode.parentNode.getAttribute('data-render');
            var holderIdVal = `holder-${holderIdIndex}`
            e.target.parentNode.remove();
            var targetItem = e.target.getAttribute("data-range-index");
            var delElement = rangValusAray[holderIdIndex].indexOf(targetItem);
            rangValusAray[holderIdIndex].splice(delElement, 1)
            $(`#${holderIdVal}`).attr("value", rangValusAray[holderIdIndex])

        }
    })

    $('.songRange').change(function () {
        document.querySelectorAll('.songRange')
        $(this).prev().text($(this).val())
        var rangeFileIndex = $(this).parent().parent().attr("data-render");
        var rangeFileId = `mp3Browser-${rangeFileIndex}`
        this.parentNode.parentNode.parentNode.children[1].children[0].setAttribute('for', rangeFileId)
        if ($(this).val() == 0) {
            this.parentNode.parentNode.parentNode.children[1].children[0].setAttribute('for', "")
            this.parentNode.parentNode.parentNode.children[1].children[1].value = '';
        } else {
            this.parentNode.parentNode.parentNode.children[1].children[0].setAttribute('for', rangeFileId)
        }
    })
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\naijacrawl soft\demo_mp3tager\resources\views/pages/tags.blade.php ENDPATH**/ ?>