
<?php $__env->startSection('title'); ?>
<title>Upload mp3 -  join two mp3 files online | mp3 tager for editing mp3 and Mp4  files <?php echo e(date('Y')); ?></title>
<meta name="description" content="Upload and use this free online editor tool for editing mp3 and Mp4  files   , join mp3  or voice tag , editing of mp3 tags like changing the cover art , album, title, of any mp3 files " />
<meta name="keywords" content="Upload mp3 -  join two mp3 and Mp4  files online | mp3 tager for editing mp3 files" />
<meta name="apple-mobile-web-app-title" content="Mp3Tager" />
<meta property="fb:app_id" content="" />
<meta name="theme-color" content="#08192D"/>
<meta property="og:title" content="Upload mp3 -  join two mp3 and Mp4  files online | mp3 tager for editing mp3 files" />
<meta property="og:description" content="Upload and use this free online editor tool for editing mp3 and Mp4  files   , join mp3  or voice tag , editing of mp3 tags like changing the cover art , album, title, of any mp3 files " />
<meta property="og:url" content="<?php echo e(url('/')); ?>" />
<meta property="og:type" content="website" />
<meta property="og:site_name" content="Mp3Tager" />
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@mp3tager">
<meta name="twitter:title" content="Upload mp3 -  join two mp3 and Mp4  files online | mp3 tager for editing mp3 files">
<meta name="twitter:description" content="Upload and use this free online editor tool for editing mp3 and Mp4  files   , join mp3  or voice tag , editing of mp3 tags like changing the cover art , album, title, of any mp3 files ">
<link rel="canonical" href="<?php echo e(url('/')); ?>" />
<meta property="og:image" content="<?php echo e(url(config('app.logo'))); ?>" />
<meta property="og:image:alt" content="Upload mp3 -  join two mp3 files online | mp3 tager for editing mp3 and Mp4  files">
<meta property="og:image:type" content="image/png" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta name="twitter:image" content="<?php echo e(url(config('app.logo'))); ?>" />
<meta name="twitter:image:alt" content="Upload mp3 -  join two mp3 files online | mp3 tager for editing mp3 and Mp4  files" />
<link rel="stylesheet" href="<?php echo e(asset('css/download.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="Mycontainer">
    <div class="msg-content">
        <?php if(config('app.ads_enable') == true): ?>
        <?php echo $__env->make('layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <p class="bg-success text-center text-white p-2 mt-5">your settings saved successfully <i class="fas fa-thumbs-up"></i></p>
        <div id="accordion">
            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $download): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card-header-card" id="heading<?php echo e($key); ?>">
                <a href="#" class=" <?php if($key == 0): ?> <?php else: ?> collapsed <?php endif; ?>" data-toggle="collapse" data-target="#collapse<?php echo e($key); ?>" aria-expanded="<?php if($key == 0): ?> true <?php else: ?> false <?php endif; ?>" aria-controls="collapse<?php echo e($key); ?>">

                    <div class="download-songs " style="background-color: #d4edda; color: #000">

                        <span class='badge badge-primary'> <?php echo e($loop->iteration); ?></span> <?php echo e($download->file_name); ?> <i class="fa fa-plus"></i>

                    </div>
                </a>
            </div>
            <article id="collapse<?php echo e($key); ?>" class="collapse <?php if($key == 0): ?> show <?php endif; ?>" aria-labelledby="heading<?php echo e($key); ?>" data-parent="#accordion">
                <div class="download-songs">click <a <?php if($p == true): ?> href="<?php echo e(url($download_path.$download->slug)); ?>"  <?php else: ?>  href="<?php echo e(url($download_path.$download->time_folder.$download->slug)); ?>" <?php endif; ?>> Here  <i class="fa fa-download"></i> </a> to download your file
                    <span class="badge badge-danger"><?php echo e($download->size); ?></span> 
                    <button class="badge badge-primary down-btn-item clip-btn"> copy <i class="fas fa-copy"></i></button> link to clipborad 
                    <input type="text" style="opacity: 0;">
                    <br/>

                    <br/> <br/>
                    <?php if($download->mime_type == 'mp3'): ?>
                    <audio controls style="width:100%" loop>
                        <?php if($p == true): ?>
                        <source src="<?php echo e(url($download_path.$download->slug)); ?>" type="audio/ogg">
                        <source src="<?php echo e(url($download_path.$download->slug)); ?>" type="audio/mpeg">
                        <?php else: ?>
                        <source src="<?php echo e(url($download_path.$download->time_folder.$download->slug)); ?>" type="audio/ogg">
                        <source src="<?php echo e(url($download_path.$download->time_folder.$download->slug)); ?>" type="audio/mpeg">

                        <?php endif; ?>
                        Your browser does not support the audio element.
                    </audio>

                    <br/> <br/>
                    <textarea cols="50" rows="5" class="embd-txt" style="width:100%">
                <audio controls style="width:100%" loop>
                     <?php if($p == true): ?>
                      <source src="<?php echo e(url($download_path.$download->slug)); ?>" type="audio/ogg">
                    <source src="<?php echo e(url($download_path.$download->slug)); ?>" type="audio/mpeg">
                     <?php else: ?>
                     <source src="<?php echo e(url($download_path.$download->time_folder.$download->slug)); ?>" type="audio/ogg">
                    <source src="<?php echo e(url($download_path.$download->time_folder.$download->slug)); ?>" type="audio/mpeg">
                  
                    <?php endif; ?>
                  Your browser does not support the audio element.
                  </audio>

                    </textarea>
                    <?php else: ?>
                     <?php if($download->mime_type == 'jpg' || $download->mime_type == 'png' || $download->mime_type == 'jpeg' || $download->mime_type == 'gif'): ?>
                        <?php if($p == true): ?>
                        
              <img src="<?php echo e(url($download_path.$download->slug)); ?>" width="300" height="150"/>
                         <?php else: ?>
                         
              <img src="<?php echo e(url($download_path.$download->time_folder.$download->slug)); ?>" width="300" height="150"/>
                         <?php endif; ?>
                    <?php else: ?>
                    <video style="width:100%" controls loop>
                        <?php if($p == true): ?>
                        <source src="<?php echo e(url($download_path.$download->slug)); ?>" type="video/mp4">
                        <source src="<?php echo e(url($download_path.$download->slug)); ?>" type="video/ogg">
                        <?php else: ?>
                        <source src="<?php echo e(url($download_path.$download->time_folder.$download->slug)); ?>" type="video/mp4">
                        <source src="<?php echo e(url($download_path.$download->time_folder.$download->slug)); ?>" type="video/ogg">

                        <?php endif; ?>
                        Your browser does not support HTML video.
                    </video>
                    <?php endif; ?>
                    <br/> <br/>
                    <textarea cols="50" rows="5" class="embd-txt" style="width:100%">
               <?php if($download->mime_type == 'jpg' || $download->mime_type == 'png' || $download->mime_type == 'jpeg' || $download->mime_type == 'gif'): ?>
                        <?php if($p == true): ?>
                      <img src="<?php echo e(url($download_path.$download->slug)); ?>" width="100" height="100"/>
                         <?php else: ?>
                          <img src="<?php echo e(url($download_path.$download->time_folder.$download->slug)); ?>" width="100" height="100"/>
                         <?php endif; ?>
             
                    <?php else: ?>
                <video style="width:100%" controls loop>
                  <?php if($p == true): ?>
                <source src="<?php echo e(url($download_path.$download->slug)); ?>" type="video/mp4">
                <source src="<?php echo e(url($download_path.$download->slug)); ?>" type="video/ogg">
                <?php else: ?> 
                 <source src="<?php echo e(url($download_path.$download->time_folder.$download->slug)); ?>" type="video/mp4">
                <source src="<?php echo e(url($download_path.$download->time_folder.$download->slug)); ?>" type="video/ogg">
               
                <?php endif; ?>
                
                Your browser does not support HTML video.
            </video>
              <?php endif; ?>

                    </textarea>
                    <?php endif; ?>

                    <button class="embd-btn">copy embedded code</button>
                </div> 
                <?php if(config('app.ads_enable') == true): ?>
                <?php echo $__env->make('layouts.text', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <div class="clearfix"></div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>

</div>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $('.clip-btn').click(function () {
            var targetTxt = $(this).next();
            var targetLink = $(this).prev().prev();
            var linKVal = targetTxt.val();
            targetTxt.val(targetLink.attr('href'));
            var copyText = targetTxt;
            copyText.select();
            document.execCommand("copy");
            let message = "Copied the text: " + copyText.val();
            toastr.success(message, {timeOut: 50000});
        });

        $('.embd-btn').click(function () {
            var targetTextArea = $(this).prev();
            var copyTextArea = targetTextArea;
            copyTextArea.select();
            document.execCommand("copy");
            let message = "Embedded Code Copied Successfully , you can use it on your website for post";
            toastr.success(message, {timeOut: 50000});
        });



    })
</script>
<script>
    $(document).ready(function () {
        // Add minus icon for collapse element which is open by default
        $(".collapse.show").each(function () {
            $(this).prev(".card-header-card").find(".fa").addClass("fa-minus").removeClass("fa-plus");
        });

        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function () {
            $(this).prev(".card-header-card").find(".fa").removeClass("fa-plus").addClass("fa-minus");
        }).on('hide.bs.collapse', function () {
            $(this).prev(".card-header-card").find(".fa").removeClass("fa-minus").addClass("fa-plus");
        });
    });
</script>
<script>
    $(document).ready(function () {
        // Get saved data from sessionStorage
        let selectedCollapse = sessionStorage.getItem('selectedCollapse');
        if (selectedCollapse !== null) {
            $('.accordion .collapse').removeClass('show');
            $(selectedCollapse).addClass('show');
        }
        //To set, which one will be opened
        $('.accordion .btn-link').on('click', function () {
            let target = $(this).data('target');
            //Save data to sessionStorage
            sessionStorage.setItem('selectedCollapse', target);
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\naijacrawl soft\demo_mp3tager\resources\views/pages/download.blade.php ENDPATH**/ ?>