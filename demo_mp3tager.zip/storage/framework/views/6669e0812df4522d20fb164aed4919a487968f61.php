<?php $__env->startSection('title'); ?>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Tell the browser to be responsive to screen width -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Mp3tag Register">
<meta name="author" content="Mp3tag">
<meta name="theme-color" content="#08192D"/>
<meta property="og:description" content="Mp3tag Register" />
<title>Mp3tag - Register Page</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<main class="signup-page">
        <section class="signup">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="p-4">
                            <h5 class="mb-5 text-center">
                                Create an account
                            </h5>
                            <img src="<?php echo e(asset('images/developers-doing-discussion-about-wireframe-1.jpg')); ?>" class="img-fluid"
                                width="500px">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="login-form">
                            <form action="#" id='register'>
                                <div class="form-group">
                                     <input type="hidden"  id="actions" value="tag">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" name="username" id="username" class="form-control form-input">
                                    <i class="input__icon fas fa-user"></i>
                                </div>
                                <div class="form-group">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="text" name="email" id="email" class="form-control form-input">
                                    <i class="input__icon fas fa-envelope"></i>
                                </div>
                                <div class="form-group">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" name="password" id="password"
                                        class="form-control form-input">
                                    <i class="input__icon fas fa-key"></i>
                                </div>
                                <div class="form-group">
                                    <label for="cpassword" class="form-label">Confirm Password</label>
                                    <input type="password" name="cpassword" id="confirm_password"
                                        class="form-control form-input">
                                    <i class="input__icon fas fa-key"></i>
                                </div>
                               
                                <div class="custom-control custom-checkbox mb-4">
                                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                                    <label class="custom-control-label" for="customCheck1">Accept our <a href="#">Terms & Conditions</a></label>
                                </div>
                                <input type='hidden' id="ref" value="<?php echo e($ref); ?>" class="form-control">
                                <div class="form-group">
                                    <button class="btn btn-primary px-5 py-2">Sign Up</button> <a href="<?php echo e(url('signin')); ?>" class="btn ml-3"> Log In</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>


<?php $__env->startSection('script'); ?>
<script>
    /*
     register
     */
    $('#register').submit(function (event) {
        event.preventDefault();
        var checkbox = document.getElementById("customCheck1");
        if (checkbox.checked) {
        } else {
            toastr.warning("You Must Agree To Our Terms, Click the CheckBox", {timeOut: 50000});
            return false;
        }
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            beforeSend: function () {
                $(".modal").show();
            },
            complete: function () {
                $(".modal").hide();
            }
        });
        jQuery.ajax({
            url: "<?php echo e(url('/signup')); ?>",
            type: 'POST',
            data: {
                username: jQuery('#username').val(),
                email: jQuery('#email').val(),
                password: jQuery('#password').val(),
                confirm_password: jQuery('#confirm_password').val(),
                actions: jQuery('#actions').val(),
                ref: jQuery('#ref').val()
            },
            success: function (data) {
                if (data.data['status'] === 401) {
                    jQuery.each(data.data['message'], function (key, value) {
                        var message = ('' + value + '');
                        toastr.options.onHidden = function () {
                            //window.location.href = "<?php echo e(url('/register')); ?>";
                        };
                        toastr.error(message, {timeOut: 50000});
                    });
                    return false;
                }
                 if (data.data['status'] === 422) {
                        var message = data.data['message'];
                        toastr.error(message, {timeOut: 50000});

                        return false;
                    }
                
                if (data.data['status'] === 200) {
                    jQuery.each(data.data['message'], function (key, value) {
                        var message = ('' + value + '');
                        toastr.options.onHidden = function () {
                            window.location.href = "<?php echo e(url('/dashboard')); ?>";
                        };
                        toastr.success(message, {timeOut: 50000});
                    });
                    return false;
                }
            }

        });
    });</script> 
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\naijacrawl soft\mp3tag\resources\views/pages/signup.blade.php ENDPATH**/ ?>