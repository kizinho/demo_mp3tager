
<div class="navigation container">
        <nav class="navbar navbar-expand-lg navbar-light px-0">
            <a class="navbar-brand logo" href="<?php echo e(url('/')); ?>">
                <i class="fas fa-compact-disc logo__icon"></i>
                Mp3Tager
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav m-auto">
                 
                    <li class="nav-item <?php if(request()->path() == '/'): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(url('upload')); ?>">Start Editing</a>
                    </li>
                   
                     <li id="google_translate_element"></li>
                </ul>
                
            </div>
        </nav>
    </div><?php /**PATH C:\xampp\htdocs\naijacrawl soft\customMp3Tager\mp3tagCustom\resources\views/layouts/nav.blade.php ENDPATH**/ ?>