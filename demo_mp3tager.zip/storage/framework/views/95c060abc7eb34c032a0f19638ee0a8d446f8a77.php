     <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2020 <a href="/" target="_blank">Mp3tager</a>. All rights reserved.</span>
            
          </div>
        </footer><?php /**PATH C:\xampp\htdocs\naijacrawl soft\mp3tag\resources\views/layouts/footeruser.blade.php ENDPATH**/ ?>