
<!-- --------------Start of navigation bar--------- -->
<!-- <div class="navbar">
    <div class="logo">
        <a href="<?php echo e(url('/')); ?>"><i class="fas fa-compact-disc"></i>
            Mp3Tager<span>.com</span></a>
    </div>
    <div class="nav-links">
        <label id="chk-list-hide"><i class="fa fa-bars"></i></label>
        <ul>
            <li><a class="<?php if(request()->path() == '/'): ?> active <?php endif; ?>" href="<?php echo e(url('/')); ?>" class="active">home</a></li>
            <li><a class="start-upload-btn <?php if(request()->path() == 'upload'): ?> active <?php endif; ?> <?php if(request()->path() == 'tags'): ?> active <?php endif; ?> <?php if(request()->path() == 'downloads'): ?> active <?php endif; ?>" href="<?php echo e(url('upload')); ?>" >Start Uploading</a></li>
          <li><a class="<?php if(request()->path() == 'how-it-works'): ?> active <?php endif; ?> <?php if(request()->path() == 'how-it-works'): ?> active <?php endif; ?>" href="<?php echo e(url('how-it-works')); ?>" class="start-upload-btn">How it Works?</a></li>
            
            <li> -->
                <!-- doropdown list -->
                <!-- <div class="dropdown active">
                    <button class="btn dropdown-toggle " type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Contact 
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="<?php echo e(url('contact-us')); ?>">Contact Us</a>
                        <a class="dropdown-item" href="<?php echo e(url('about-us')); ?>">About Us</a>
                        <a class="dropdown-item" href="<?php echo e(url('privacy-policy')); ?>">Privacy & Policy</a>
                        <a class="dropdown-item" href="<?php echo e(url('tos')); ?>">Terms Of Service</a>
                    </div>
                </div> -->
                <!-- End of dropdown list -->
            <!-- </li>
            <?php if($user == false): ?>
            
            <li><a class="<?php if(request()->path() == 'signup'): ?> active <?php endif; ?>"  href="<?php echo e(url('signup')); ?>">Sign up</a></li>
            <li><a class="<?php if(request()->path() == 'signin'): ?> active <?php endif; ?>"  href="<?php echo e(url('signin')); ?>">Sign in<i class="fas fa-sign-in-alt"></i></a></li>
            <?php else: ?>
            <li><a class="<?php if(request()->path() == 'dashboard'): ?> active <?php endif; ?>"  href="<?php echo e(url('dashboard')); ?>"><?php echo e($user->username); ?> <i class="fas fa-user"></i></a></li>
            <?php endif; ?>
              <li id="google_translate_element"></li>


        </ul>
    </div>
</div> -->

<div class="navigation container">
        <nav class="navbar navbar-expand-lg navbar-light px-0">
            <a class="navbar-brand logo" href="<?php echo e(url('/')); ?>">
                <i class="fas fa-compact-disc logo__icon"></i>
                Mp3Tager
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav m-auto">
                    <li class="nav-item <?php if(request()->path() == '/'): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item <?php if(request()->path() == 'pricing'): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(url('pricing')); ?>">Pricing</a>
                    </li>
                    <li class="nav-item <?php if(request()->path() == 'upload'): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(url('upload')); ?>">Start Editing</a>
                    </li>
                    <li class="nav-item <?php if(request()->path() == 'how-it-works'): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(url('how-it-works')); ?>">How it works</a>
                    </li>
                     <li id="google_translate_element"></li>
                </ul>
                <ul class="navbar-nav ml-md-auto">
                    <li class="nav-item mr-md-3">
                        <a class="nav-link" href="<?php echo e(url('signin')); ?>">Log in</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn--signup px-4 text-light" href="<?php echo e(url('signup')); ?>">Create Account</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div><?php /**PATH C:\xampp\htdocs\naijacrawl soft\mp3tag\resources\views/layouts/nav.blade.php ENDPATH**/ ?>