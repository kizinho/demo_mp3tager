<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" />
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
 <!-- Main Page Title -->
    <!-- Favicons -->
    <link rel="icon" href="<?php echo e(asset('logo/logo.png')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('logo/logo.png')); ?>">
    <link rel="apple-touch-icon"   href="<?php echo e(asset('logo/logo.png')); ?>">
    <link rel="apple-touch-icon"  href="<?php echo e(asset('logo/logo.png')); ?>">
    <link rel="apple-touch-icon"  href="<?php echo e(asset('logo/logo.png')); ?>">
    <link rel="apple-touch-icon"  href="<?php echo e(asset('logo/logo.png')); ?>">
    <?php echo $__env->yieldContent('title'); ?>
      <link rel="stylesheet" href="<?php echo e(asset('assets/new/vendors/iconfonts/font-awesome/css/all.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/new/vendors/css/vendor.bundle.base.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/new/vendors/css/vendor.bundle.addons.css')); ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/new/css/style.css')); ?>">
   
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" />
    <link href="<?php echo e(asset('sweetalert/sweetalert.css')); ?>" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Baloo+Bhai&amp;display=swap" rel="stylesheet">
    
</head>

<body class="sidebar-dark">
  <div class="container-scroller">
        <?php echo $__env->make('layouts.navuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
      
          <div class="modal" style="display: none">
                <div class="mcenter">
                    <img src="<?php echo e(asset('images/reload.gif')); ?>"  >
                </div>
            </div>
        <?php echo $__env->make('layouts.footeruser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
 <script src="<?php echo e(asset('assets/new/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/new/vendors/js/vendor.bundle.addons.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo e(asset('assets/new/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/new/js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/new/js/misc.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/new/js/settings.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/new/js/todolist.js')); ?>"></script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-161752442-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-161752442-1');
</script>

    <script type="text/javascript">
function googleTranslateElementInit() {
    new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
      <script src="<?php echo e(asset('sweetalert/sweetalert.min.js')); ?>"></script>
       <script>
            $(".deleted").on("submit", function () {

                return confirm("Are you sure?");
            });
        </script>

        <script>
            $(".deleted-list").on("submit", function () {

                return confirm("Are you sure?");
            });
        </script>
        <script>
   $(document).ready(function () {
  setInterval(function () {
    if ($('html').hasClass('translated-ltr')) {
      $('.navbar').css('margin-top', '30px');
    } else {
      $('.navbar').css('margin-top', '0px');
    }
  }, 3000);
   });
        </script>
<?php if(session()->has('message.level')): ?>
<script type="text/javascript">
    swal({
        title: "<?php echo e(session('message.level')); ?>",
        html: true,
        text: "<span style='color:<?php echo e(session('message.color')); ?>;font-size:20px;margin:10px'><?php echo session('message.content'); ?>",
        timer: 10000,
        type: "<?php echo e(session('message.level')); ?>",
         confirmButtonColor: "#0000cc"
    }).then((value) => {
        //location.reload();
    }).catch(swal.noop);
</script>
<?php endif; ?>
<!-- <script>

/*Register Service Worker if it is supported*/
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/mp3sw.js').then(event => {
        }).catch((err) => {
            console.log(err);
        });
    });
} else {
    console.log('No service worker');
}

    </script>-->
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\naijacrawl soft\mp3tag\resources\views/layouts/home.blade.php ENDPATH**/ ?>