<?php $__env->startSection('title'); ?>
<title>Mp3tager &mdash; <?php echo e($user->username); ?> Dashbord</title>
<meta  name="description" content="<?php echo e($user->username); ?> Dashbord">
<meta itemprop="keywords" name="keywords" content="Mp3tager &mdash; <?php echo e($user->username); ?> Dashbord"/>
<meta name="author" content="Mp3tager" />
<style>

    .nav-pills {
        border-bottom: none !important; 
    }
    .tab-content {
        border: none !important; 
    }
    .circle {
        border-radius: 50%;
    }
    .bg-orange {
        background-color: #CD6133;
    }

    .m-icon {
        font-size: 20px  
    }
    .l-icon {
        font-size: 40px  
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="main-panel">

    <div class="content-wrapper">
        <div class="row">


            <div class="col-md-12 ">
                <div class="card">
                    <div class="card-body account-panel">
                        <!--                start content-->




                        <div class="row">
                            <div class="col-md-9"
                                 <!-- Tab panes -->
                                 <div class="tab-content">
                                    <div class="tab-pane container active" id="profile">


                                        <h5 class="text-muted mb-5"> Personal Info </h5>

                                        <div class="row">

                                            <div class="col-md-3">
                                                <div class="text-center" style="width:5rem">
                                                    <i class="p-4 bg-orange circle fa fa-user l-icon text-white  d-none d-md-block" ></i>
                                                    <i class="p-3 bg-orange circle fa fa-user m-icon text-white d-md-none" ></i>


                                                    <span class="d-md-none" > Basic Info </span>
                                                    <span class="mt-2 d-none d-md-block "> Basic Info </span>
                                                </div>
                                            </div>
                                            
                                              <div class="row">
                                            <div class="col-md-9">
                                              
                                                <p class="mb-4 mt-5">
                                                    You can change your primary email address and Name at any time.</p>

                                                    <div class="col-lg-4">
                                                        <p class="">Name</p> 
                                                    </div>
                                                    <div class="col-lg-8">
                                                        <p class="">Adike Kizito
                                                        </p>
                                                    </div> 
                                                  
                                                    <div class="col-lg-4"> 
                                                        <p class="">Username</p>
                                                    </div> 
                                                    <div class="col-lg-8">
                                                        kizinho
                                                        <div>
                                                            Since Jun 17, 2016 (4 years, 18 days ago)
                                                        </div>

                                                    </div> 

                                                  
                                                    <div class="col-lg-4"> 
                                               
                                                        <p class=" ">
                                                            Primary Email
                                                        </p> 
                                                    </div> 
                                                    <div class="col-lg-8"> 
                                                        
                                                        <p  class="">adikekizinho@gmail.com</p>

                                                    </div> 
                                                    <div class="text-center">
                                                        <a class="btn btn-danger btn-sm text-white">EDIT</a>
                                                    </div>  
                                                  
                                                </div>
                                            </div>


                                        </div>





                                        <!--                                        <form action="/action_page.php">
                                                                                    <div class="row">
                                                                                        <div class="col-md-6">
                                                                                            <div class="form-group">
                                                                                                <label for="uname">Username:</label>
                                                                                                <input type="text" class="form-control"  placeholder="Enter username" value="<?php echo e($user->username); ?>" readonly="">
                                                                                            </div>
                                                                                        </div>
                                        
                                                                                        <div class="col-md-6">
                                                                                            <div class="form-group">
                                                                                                <label for="email">Email:</label>
                                                                                                <input type="text" class="form-control" value="<?php echo e($user->email); ?>" id="email" placeholder="Enter Email" name="email" required>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="text-center">
                                                                                        <button type="submit" class="btn btn-primary">Change Account Data</button>
                                                                                    </div>
                                                                                </form>-->


                                    </div>



                                    <div class="tab-pane container fade" id="sub">

                                        <h5 class="text-center text-muted">   <?php echo e($user->username); ?> - Subscriptions </h5>



                                    </div>
                                    <div class="tab-pane container fade" id="api">
                                        <h5 class="text-center text-muted">   <?php echo e($user->username); ?> - Api key </h5>


                                    </div>
                                </div>
                            </div>
                            <!-- Nav pills -->
                            <div class="col-md-3">
                                <ul class="nav nav-pills flex-column">
                                    <li class="nav-item  mt-4 mb-2">
                                        <a class="nav-link active" data-toggle="pill" href="#profile"><h5>Profile</h5></a>
                                    </li>
                                    <li class="nav-item mb-2 ">
                                        <a class="nav-link " data-toggle="pill" href="#billing"><h5>Billing</h5></a>
                                    </li>
                                    <li class="nav-item  mb-2">
                                        <a class="nav-link" data-toggle="pill" href="#sub"><h5>Subscriptions</h5></a>
                                    </li>
                                    <li class="nav-item  mb-2">
                                        <a class="nav-link" data-toggle="pill" href="#api"><h5>Api key</h5></a>
                                    </li>
                                    <li class="nav-item  mb-2">
                                        <a class="nav-link" data-toggle="pill" href="#security"><h5> Security</h5></a>
                                    </li>
                                    <li class="nav-item  mb-2">
                                        <a class="nav-link" data-toggle="pill" href="#tager"><h5> Tager Setting</h5></a>
                                    </li>
                                </ul>
                            </div>
                        </div>               


                    </div>
                </div>
            </div>
        </div>




    </div>


    <?php $__env->startSection('script'); ?>

    <script>
        /*
         server
         */
        $('#server').submit(function (event) {
            event.preventDefault();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                beforeSend: function () {
                    $(".modal").show();
                },
                complete: function () {
                    $(".modal").hide();
                }
            });
            jQuery.ajax({
                url: "<?php echo e(url('/add-storage')); ?>",
                type: 'POST',
                data: {
                    size: jQuery('#size').val(),
                    storage: jQuery('#storage').val(),
                    action: jQuery('#action').val()
                },
                success: function (data) {
                    if (data.data['status'] === 401) {
                        jQuery.each(data.data['message'], function (key, value) {
                            var message = ('' + value + '');
                            toastr.error(message, {timeOut: 50000});
                        });
                        return false;
                    }

                    if (data.data['status'] === 200) {
                        var message = data.data['message'];
                        toastr.options.onHidden = function () {
                            window.location.href = "<?php echo e(url('/add-storage')); ?>";
                        };
                        toastr.success(message, {timeOut: 50000});

                        return false;
                    }
                }

            });
        });</script> 

    <script>
        /*
         drive
         */
        $('#drive').submit(function (event) {
            event.preventDefault();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                beforeSend: function () {
                    $(".modal").show();
                },
                complete: function () {
                    $(".modal").hide();
                }
            });
            jQuery.ajax({
                url: "<?php echo e(url('/add-drive')); ?>",
                type: 'POST',
                data: {
                    storage: jQuery('#storage_drive').val()
                },
                success: function (data) {
                    if (data.data['status'] === 401) {
                        jQuery.each(data.data['message'], function (key, value) {
                            var message = ('' + value + '');
                            toastr.error(message, {timeOut: 50000});
                        });
                        return false;
                    }
                    if (data.data['status'] === 422) {
                        var message = data.data['message'];
                        toastr.error(message, {timeOut: 50000});

                        return false;
                    }
                    if (data.data['status'] === 200) {
                        var message = data.data['message'];
                        toastr.options.onHidden = function () {
                            window.location.href = "<?php echo e(url('/add-storage')); ?>";
                        };
                        toastr.success(message, {timeOut: 50000});

                        return false;
                    }
                }

            });
        });
    </script> 
    <?php $__env->stopSection(); ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\naijacrawl soft\mp3tag\resources\views/users/account-settings.blade.php ENDPATH**/ ?>