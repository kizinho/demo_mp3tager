<div class="text-center mb-5 mt-3">
    
    <a href="{{config('app.banner_ad_image_link')}}" target="_blank" > <img src="{{config('app.banner_ad_image')}}" width="{{config('app.banner_ad_image_width')}}" height="{{config('app.banner_ad_image_height')}}" alt="banner ads"> </a>
</div>