<footer class="footer">
        <div class="container">
            <div class="row">
               
               
            </div>
            <div class="text-center">
                <p>
                    <a class="logo" href="{{url('/')}}">
                       <img src="{{url(config('app.logo'))}}" width='50'  height="50" class=" logo__icon">
               {{config('app.name')}}
                    </a>
                    
                    Copyright © 2020-{{date('Y')}} Theme by Kizsoft, powered by <a class="" href="https://kizzsoft.com" target="_blank">Kizsoft Solution Service</a>
   
                </p>
            </div>
        </div>
    </footer>