<div class="text-center mb-5 mt-4">
    <a rel="nofollow" class="text-ads"  href="{{config('app.text_ad_link')}}" target="_blank">
     {{config('app.text_ad')}}

    </a>
    <a rel="nofollow" class="text-ads"  href="{{config('app.text_ad_link_1')}}" target="_blank">
      {{config('app.text_ad_1')}}

    </a>
</div>