
<div class="navigation container">
        <nav class="navbar navbar-expand-lg navbar-light px-0">
            <a class="navbar-brand logo" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(url(config('app.logo'))); ?>" width='50'  height="50" class=" logo__icon">
               <?php echo e(config('app.name')); ?>

            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav m-auto">
                 
                    <li class="nav-item <?php if(request()->path() == '/'): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(url('upload')); ?>">Start Editing</a>
                    </li>
                      <li class="nav-item <?php if(request()->path() == 'image-editing'): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(url('image-editing')); ?>">Image Editing</a>
                    </li>
                    <li class="nav-item <?php if(request()->path() == 'my-files'): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(url('my-files')); ?>">My Files</a>
                    </li>
                       <li class="nav-item">
                        <a class="nav-link cache" href="<?php echo e(url('cache-clear')); ?>">Clear Cache</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link update" href="<?php echo e(url('update-tager')); ?>">Update Tager</a>
                    </li>
                     <li id="google_translate_element"></li>
                </ul>
                
            </div>
        </nav>
    </div><?php /**PATH C:\xampp\htdocs\naijacrawl soft\demo_mp3tager\resources\views/layouts/nav.blade.php ENDPATH**/ ?>