<footer class="footer">
        <div class="container">
            <div class="row">
               
               
            </div>
            <div class="text-center">
                <p>
                    <a class="logo" href="<?php echo e(url('/')); ?>">
                       <img src="<?php echo e(url(config('app.logo'))); ?>" width='50'  height="50" class=" logo__icon">
               <?php echo e(config('app.name')); ?>

                    </a>
                    
                    Copyright © 2020-<?php echo e(date('Y')); ?> Theme by Kizsoft, powered by <a class="" href="https://kizzsoft.com" target="_blank">Kizsoft Solution Service</a>
   
                </p>
            </div>
        </div>
    </footer><?php /**PATH C:\xampp\htdocs\naijacrawl soft\Usherloaded.comMp3Tag\resources\views/layouts/footer.blade.php ENDPATH**/ ?>